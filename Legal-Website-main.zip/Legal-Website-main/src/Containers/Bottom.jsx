const Bottom=()=>{
    return <div className="bg-bottom text-gray-400 text-center p-6 text-sm">
        © 2017, All Rights Reserved.
    </div>
};

export default Bottom;